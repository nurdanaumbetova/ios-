import Foundation
// Task 9: Simple Calculator

func add(_ a: Double, _ b: Double) -> Double { return a + b }
func subtract(_ a: Double, _ b: Double) -> Double { return a - b }
func multiply(_ a: Double, _ b: Double) -> Double { return a * b }
func divide(_ a: Double, _ b: Double) -> Double? {
    return b == 0 ? nil : a / b   // проверка деления на ноль
}

while true {
    print("\nВведите первое число (или 'exit' для выхода):")
    if let input = readLine(), input.lowercased() == "exit" {
        break   // выходим из программы
    } else if let input = readLine(), let a = Double(input) {
        
        print("Введите второе число:")
        if let inputB = readLine(), let b = Double(inputB) {
            
            print("Выберите операцию (+ - * /):")
            let op = readLine() ?? "+"
            
            var result: Double? = nil
            if op == "+" { result = add(a, b) }
            else if op == "-" { result = subtract(a, b) }
            else if op == "*" { result = multiply(a, b) }
            else if op == "/" { result = divide(a, b) }
            
            if let r = result {
                print("Результат: \(r)")
            } else {
                print("Ошибка: деление на ноль")
            }
        }
    }
}
