import Cocoa
// Print numbers 1 to 100, replacing some with Fizz/Buzz
for i in 1...100 {
    if i % 3 == 0 && i % 5 == 0 {
        print("FizzBuzz")   // divisible by 3 and 5
    } else if i % 3 == 0 {
        print("Fizz")       // divisible by 3
    } else if i % 5 == 0 {
        print("Buzz")       // divisible by 5
    } else {
        print(i)            // normal number
    }
}

