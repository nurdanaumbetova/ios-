import Foundation

// Task 4: Shopping List Manager

var shoppingList: [String] = []   // создаём пустой список покупок (массив строк)

while true {   // бесконечный цикл (будет идти пока не выберем "Exit")
    print("\nМеню: 1 - Добавить, 2 - Удалить, 3 - Показать список, 4 - Выйти")
    
    if let choice = readLine(), let option = Int(choice) {   // читаем выбор пользователя и превращаем в число
        
        if option == 1 {   // если пользователь выбрал "1"
            print("Введите продукт для добавления:")
            if let item = readLine() {   // читаем продукт
                shoppingList.append(item)   // добавляем его в список
                print("Добавлено: \(item)")
            }
            
        } else if option == 2 {   // если пользователь выбрал "2"
            print("Введите продукт для удаления:")
            if let item = readLine(), let index = shoppingList.firstIndex(of: item) {
                shoppingList.remove(at: index)   // удаляем продукт, если он есть в списке
                print("Удалено: \(item)")
            } else {
                print("Такого продукта нет в списке")
            }
            
        } else if option == 3 {   // если пользователь выбрал "3"
            print("Текущий список: \(shoppingList)")
            
        } else if option == 4 {   // если пользователь выбрал "4"
            print("Выход из программы...")
            break   // прерываем цикл -> программа завершена
            
        } else {
            print("Неверный ввод, попробуйте снова")  // если число не 1-4
        }
    }
}


