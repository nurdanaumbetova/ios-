import Foundation
// Task 8: Palindrome Checker

func isPalindrome(_ text: String) -> Bool {
    // приводим всё к нижнему регистру и оставляем только буквы
    let clean = text.lowercased().filter { $0.isLetter }
    // создаём строку из перевёрнутой последовательности
    let reversed = String(clean.reversed())
    // сравниваем очищенную строку и её перевёрнутую версию
    return clean == reversed
}

print("Введите слово или фразу:")   // просим ввести текст

if let input = readLine() {         // считываем ввод пользователя
    if isPalindrome(input) {
        print("Это палиндром")
    } else {
        print("Это не палиндром")
    }
}



