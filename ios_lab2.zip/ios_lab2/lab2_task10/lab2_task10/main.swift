import Foundation
// Task 10: Unique Characters

func hasUniqueCharacters(_ text: String) -> Bool {
    var seen: Set<Character> = []   // множество для хранения встреченных символов
    
    for char in text {              // перебираем каждый символ строки
        if seen.contains(char) {    // если символ уже встречался
            return false            // значит строка не уникальная
        }
        seen.insert(char)           // добавляем символ в множество
    }
    return true                     // если повторов не было → все уникальные
}

print("Введите строку:")            // просим пользователя ввести текст
if let input = readLine() {
    if hasUniqueCharacters(input) {
        print("Все символы уникальные")
    } else {
        print("Есть повторяющиеся символы")
    }
}


