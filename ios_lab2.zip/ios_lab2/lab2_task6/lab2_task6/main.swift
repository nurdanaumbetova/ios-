import Foundation
// Task 6: Fibonacci Sequence
func fibonacci(_ n: Int) -> [Int] {
    if n <= 0 { return [] }        // если число отрицательное или 0 → пустой массив
    if n == 1 { return [0] }       // если n = 1 → только первое число
    
    var seq = [0, 1]               // начинаем с 0 и 1
    for _ in 2..<n {
        let next = seq[seq.count - 1] + seq[seq.count - 2]  // сумма двух последних чисел
        seq.append(next)
    }
    return seq
}

print("Введите количество чисел Фибоначчи:")
if let input = readLine(), let n = Int(input) {
    print("Последовательность: \(fibonacci(n))")
}

