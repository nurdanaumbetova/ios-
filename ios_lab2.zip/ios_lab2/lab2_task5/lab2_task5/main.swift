import Foundation
// Task 5: Word Frequency Counter

print("Введите предложение:")   // просим пользователя ввести текст
if let sentence = readLine() {   // считываем строку
    
    var frequency: [String: Int] = [:]   // словарь (слово - сколько раз встречается)
    
    // разбиваем строку на слова, делаем все маленькими буквами
    let words = sentence.lowercased().split(separator: " ")
    
    // перебираем каждое слово
    for word in words {
        let w = String(word)   // превращаем Substring в обычную строку
        frequency[w, default: 0] += 1   // увеличиваем счётчик для слова
    }
    
    // выводим результат
    print("Частота слов:")
    for (word, count) in frequency {
        print("\(word): \(count)")
    }
}


