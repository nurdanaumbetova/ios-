import Foundation
// Task 7: Grade Calculator
var students: [String: Int] = [:]   // словарь: имя → оценка

print("Введите количество студентов:")
if let input = readLine(), let count = Int(input) {
    for _ in 1...count {
        print("Имя студента:")
        let name = readLine() ?? "Unknown"
        
        print("Оценка:")
        let score = Int(readLine() ?? "0") ?? 0
        
        students[name] = score
    }
}

let scores = Array(students.values)
let average = scores.reduce(0, +) / scores.count   // среднее значение
let maxScore = scores.max() ?? 0
let minScore = scores.min() ?? 0

print("\nРезультаты:")
for (name, score) in students {
    let status = score >= average ? "выше среднего" : "ниже среднего"
    print("\(name): \(score) (\(status))")
}
print("Средний балл: \(average), Максимум: \(maxScore), Минимум: \(minScore)")

