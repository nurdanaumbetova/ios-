import Foundation
// Task 3: Temperature Converter
print("Enter temperature value:")   // просим ввести число (температуру)

if let tempInput = readLine(), let temp = Double(tempInput) {   // считываем строку и превращаем в число (Double)
    
    print("Enter unit (C for Celsius, F for Fahrenheit, K for Kelvin):")  // спрашиваем единицу измерения
    if let unit = readLine() {
        
        if unit.uppercased() == "C" {   // если пользователь ввёл "C"
            let fahrenheit = temp * 9/5 + 32   // перевод Цельсия в Фаренгейты
            let kelvin = temp + 273.15         // перевод Цельсия в Кельвины
            print("\(temp)°C = \(fahrenheit)°F")
            print("\(temp)°C = \(kelvin)K")
            
        } else if unit.uppercased() == "F" {  // если "F"
            let celsius = (temp - 32) * 5/9   // перевод Фаренгейта в Цельсии
            let kelvin = celsius + 273.15     // перевод Фаренгейта в Кельвины
            print("\(temp)°F = \(celsius)°C")
            print("\(temp)°F = \(kelvin)K")
            
        } else if unit.uppercased() == "K" {  // если "K"
            let celsius = temp - 273.15       // перевод Кельвинов в Цельсии
            let fahrenheit = celsius * 9/5 + 32   // перевод Кельвинов в Фаренгейты
            print("\(temp)K = \(celsius)°C")
            print("\(temp)K = \(fahrenheit)°F")
            
        } else {
            print("Unknown unit! Please enter C, F, or K.") // если введено что-то другое
        }
    }
}

