import Cocoa

var firstName: String = "Nurdana"
var lastName: String = "Umbetova"
var birthYear: Int = 2005
let currentYear: Int = 2025
var age: Int = currentYear - birthYear
var isStudent: Bool = true
var height: Double = 1.73
var hometown: String = "Kyzylorda"
var favoriteFood: String = "🍜ramen"

var hobby: String = "swimming🏊🏻‍♀️"
var numberOfHobbies: Int = 2
var favoriteNumber: Int = 8
var isHobbyCreative: Bool = true
var favoriteSport: String = "tennis🏓"
var favoriteMovie: String = "Hatiko🎬"
var favoriteMusic: String = "🎶pop"
var favoritePet: String = "🐈cat"

var futureGoals = "In the future, I want to have a job I truly love❤️, be financially secure💰, and travel every month✈️🌍 and visit Europe with my mom🥰🇪🇺."


let lifeStory = "My name is \(firstName) \(lastName). I am \(age) years old, born in \(birthYear). My hometown is \(hometown). My height is \(height) meters. I am currently a student: \(isStudent). I love eating \(favoriteFood). My favorite hobby is \(hobby), which is creative: \(isHobbyCreative). I have \(numberOfHobbies) hobbies in total, and my favorite number is \(favoriteNumber). I enjoy playing \(favoriteSport), watching \(favoriteMovie), listening to \(favoriteMusic), and I like \(favoritePet)s. \(futureGoals)"

print(lifeStory)





